package finalADAssessment;

import java.io.FileInputStream;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ResourceBundle;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import javafx.application.Application;
import javafx.fxml.Initializable;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;

import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import javafx.stage.Window;

public class Details extends Application implements Initializable {
	private Connection con;
	{
		try {
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/section3","root","2218261");
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public final static double WINDOW_WIDTH = 700;
	public final static double WINDOW_HEIGHT = 600;
	

   
	
	TextField txtfacultyN = new TextField();
	TextField txtfacultyP = new TextField();
	TextField txtfacultyD = new TextField();
	
	TextField txtstudentN = new TextField();
	TextField txtstudentD = new TextField();
	TextField txtstudentR = new TextField();
	
	TextField txtcourseN = new TextField();
	TextField txtcollegeN= new TextField();
	
	
	Button btnSubmitC = new Button("Submit");
	
	Label labelfaculty  = new Label("Registration Form");
	Label reg_no = new Label("Registration Number");
	Label name = new Label("Name ");
	Label roll_no = new Label("Roll Number ");
	

	
	
	Label father_name = new Label("Father's Name");
	Label mother_name = new Label("Mother's Name");
	Label course = new Label("Course");
	
	
	
	Label sem = new Label("Semester");
	Label year = new Label("Year");
	
	public void UInterface(Pane Root) throws Exception
	{
	
	
	setupTextUI(txtfacultyN, "Arial", 18, 200,200,50,true);
	setupTextUI(txtfacultyD, "Arial", 18, 200,200,110,true);
	setupTextUI(txtfacultyP, "Arial", 18, 200,200,170,true);
	
	setupTextUI(txtstudentN, "Arial", 18, 200,200,260,true);
	setupTextUI(txtstudentD, "Arial", 18, 200,200,320,true);
	setupTextUI(txtstudentR, "Arial", 18, 200,200,380,true);
	
	
	setupTextUI(txtcourseN, "Arial", 18, 200,200,470,true);
	setupTextUI(txtcollegeN, "Arial", 18, 200,200,530,true);
	

	    setupLabelUI(labelfaculty, "Arail", 22 ,40, Pos.BASELINE_LEFT, 0, 10);    
	    setupLabelUI(reg_no, "Arail", 18 ,40, Pos.BASELINE_LEFT, 0, 52);    
	    setupLabelUI(name, "Arail", 18 ,40, Pos.BASELINE_LEFT, 0, 112);    
	    setupLabelUI(roll_no, "Arail", 18 ,40, Pos.BASELINE_LEFT, 0, 172);    
	    labelfaculty.setStyle("-fx-text-fill: blue");

	   
	    
	    setupLabelUI(father_name, "Arail", 18 ,40, Pos.BASELINE_LEFT, 0, 268);
	    setupLabelUI(mother_name, "Arail", 18 ,40, Pos.BASELINE_LEFT, 0, 322);
	    setupLabelUI(course, "Arail", 18 ,40, Pos.BASELINE_LEFT, 0, 382);
	    
	    
	    setupLabelUI(sem, "Arail", 18 ,40, Pos.BASELINE_LEFT, 0, 472);
	    setupLabelUI(year, "Arail", 18 ,40, Pos.BASELINE_LEFT, 0, 532);
	    
	    
	   
	    setupButtonUI(btnSubmitC, "Arial", 18,450,472);
	
	    
	Root.getChildren().addAll(labelfaculty, txtfacultyN, 
			txtstudentR,txtcourseN,txtcollegeN,txtstudentN,txtfacultyD,txtfacultyP,	reg_no,name, roll_no, father_name, mother_name,course, sem, year
			,txtstudentD, btnSubmitC);

	
	}

	
	
	public void saveInStudentMaster() throws SQLException, IOException {
		
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/section3","root","2218261");
		String sql = "insert into registraton (reg_no,roll_no,name,father_name,mother_name, course, sem,year)" + "values"+"(?,?,?,?,?,?,?)";
		PreparedStatement pstm = con.prepareStatement(sql);
	
		Row row;
		
		}
		
	public void saveInSubjectMaster() throws SQLException, IOException {
		String sql = "insert into subjectmaster(subjectcode,subjectname,maxmarks,semester,year)" + "values"+"(?,?,?,?,?)";
		PreparedStatement pstm = con.prepareStatement(sql);
	}	
	
	


	private void setupButton(Button b, int w, int x, int y) {
		b.setMinWidth(w);
		b.setAlignment(Pos.BASELINE_CENTER);
		b.setLayoutX(x);
		b.setLayoutY(y);
	}

	private void setupLabelUI(Label l, String ff, double f, double w, Pos p, double x, double y) {

		l.setFont(Font.font(ff, f));
		l.setAlignment(p);
		l.setLayoutX(x);
		l.setLayoutY(y);
	}

	
	
	private void setupTextAreaUI(TextArea a, String ff, double f, double w, double h, double x, double y, boolean e){
		a.setFont(Font.font(ff, f));
		a.setMinWidth(w);
		a.setMaxWidth(w);
		a.setMinHeight(h);
		a.setMaxHeight(h);
		a.setLayoutX(x);
		a.setLayoutY(y);		
		a.setEditable(e);
	}
	private void setupTextUI(TextField t, String ff, double f, double w, double x, double y, boolean e){
		t.setFont(Font.font(ff, f));
		t.setMinWidth(w);
		t.setMaxWidth(w);
		t.setLayoutX(x);
		t.setLayoutY(y);		
		t.setEditable(e);
	}

	private void setupButtonUI(Button t, String ff, double f, double x, double y){
		t.setFont(Font.font(ff, f));
		t.setLayoutX(x);
		t.setLayoutY(y);		
	}
	
	
	
	 public void start(Stage stage) {
			
			stage.setTitle("Student Registration");	// Label the stage (a window)
			Pane theRoot = new Pane(); 
			
			     // Create a pane within the window
			try {
	            UInterface(theRoot);        // Create the Graphical User Interface
			}
			catch(Exception e) {}
			Scene scene = new Scene(theRoot,WINDOW_WIDTH,WINDOW_HEIGHT); //Creating a scene object
		    
			stage.setScene(scene);    //Adding scene to the stage 
		      
		     stage.show();            //Displaying the contents of the stage
		}
		
		
		
		 public static void main(String args[]){ 
		      launch(args); 
		   }



		@Override
		public void initialize(URL arg0, ResourceBundle arg1) {
			// TODO Auto-generated method stub
			
		} 
	

	}

